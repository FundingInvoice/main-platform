<?php if($form): ?>
<?php print drupal_render_children($form); ?>
	  
	  <?php
	  /*
	  print "<pre>";
	  print $form['#steps']['step_step1']->step_name;
	  print_r($form);
	  print "</pre>";
	  */
	  ?>
	  
		
<?php endif; ?>


