
* SUMMARY *

Content Approval is a Drupal module that allow administrator to tell which 
content type must be published prior their publication.

Once a content type has this feature enabled it is possble to set a 
'skip content publication approval' permission for any existing role.

Then if this permission isn't set the submission content of the defined 
content type will be saved with the unpublished status, permitting 
allowed administrators to approved it or not.

That is, this functionality mimic that existing feature found in the Comment 
core module by staying as simple.

Please find more informations at http://drupal.org/sandbox/drikc/1160500

drikc on drupal.org.

